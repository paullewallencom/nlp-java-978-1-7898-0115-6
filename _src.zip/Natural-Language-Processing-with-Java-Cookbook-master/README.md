## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/natural-language-processing-with-java-cookbook/9781789801156)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/178980115X).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Natural-Language-Processing-with-Java-Cookbook
Natural Language Processing with Java Cookbook, published by Packt
